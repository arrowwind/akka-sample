package com.heitu

import akka.actor.ActorSystem
import com.heitu.akkaactor.CitaEngine
import com.heitu.akkaactor.CitaEngine.Start
import com.typesafe.config.ConfigFactory

import java.awt.Toolkit
import java.io.File
import java.util.Date
import scala.annotation.unused
import scala.collection.mutable
import scala.util.{Failure, Success, Try}

object CitaM {
    var id: String = _

    def main(args: Array[String]): Unit = {

        val locker = new Object
        val customConf = ConfigFactory.parseString(
            s"""
             akka {
               loglevel = ERROR
               log-dead-letters = 0
               log-dead-letters-during-shutdown = off
             }

             cita-dispatcher {
                  mailbox-type = "com.heitu.CitaMailBox"
             }
              """)
        val system: ActorSystem = ActorSystem("CitaSystem", ConfigFactory.load(customConf))
        try {
            val root = system.actorOf(CitaEngine.props(locker).withDispatcher("cita-dispatcher"), "CitaEngine")

            locker.synchronized {
                root ! Start

                locker.wait()
            }
        } finally {
            system.terminate()
        }
    }
}