package com.heitu

import akka.actor.ActorSystem
import akka.dispatch.{PriorityGenerator, UnboundedPriorityMailbox}
import com.heitu.akkaactor.CitaEngine.{WinnerAddCase, WinnerWorkDone, WriteWinnerReport}
import com.heitu.akkaactor.winner.alpha.WinnerAlphaEngine.{WinnerBackTestAlphaStart, WinnerBackTestAlphaStartAddCase}
import com.typesafe.config.Config

import scala.annotation.unused


@unused
class CitaMailBox(@unused val settings: ActorSystem.Settings, @unused val config: Config) extends UnboundedPriorityMailbox(new PriorityGenerator() {
    override def gen(message: Any): Int = {
        message match {
            case WinnerAddCase => 0
            case WriteWinnerReport => 1
            case WinnerWorkDone => 2
            case WinnerBackTestAlphaStartAddCase => 5
            case WinnerBackTestAlphaStart => 6
            case _ => 7
        }
    }
}) {
}
