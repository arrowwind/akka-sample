package com.heitu.akkaactor

import akka.actor.{Actor, ActorRef, Props}
import akka.routing.RoundRobinPool
import com.heitu.*
import com.heitu.akkaactor.CitaEngine.*
import com.heitu.akkaactor.winner.*
import com.heitu.akkaactor.winner.alpha.WinnerAlphaEngine
import com.heitu.akkaactor.winner.alpha.WinnerAlphaEngine.{WinnerBackTestAlphaStart, WinnerBackTestAlphaStartAddCase}

import java.util.Date
import java.util.concurrent.ConcurrentHashMap
import scala.collection.mutable.ArrayBuffer
import scala.util.{Failure, Success, Try}

object CitaEngine {
    def props(locker: Object): Props = Props(new CitaEngine(locker))

    case object Start

    final case class WinnerWorkDone(id: Int, num: Int, remove: Boolean)

    final case class WriteWinnerReport(id: Int, num: Int)

    final case class WinnerAddCase(engine: ActorRef, id: Int, num: Int)

}

class CitaEngine(val locker: Object) extends Actor {
    val result = new ConcurrentHashMap[Int, java.util.HashSet[Int]]

    // 处理开始
    override def receive: Receive = {
        case Start =>
            Try {
                val threadNum = 10

                val num = 4

                val engine = context.actorOf(RoundRobinPool(threadNum).props(WinnerAlphaEngine.props()).withDispatcher("cita-dispatcher"), "WinnerAlphaEngine")
                var sci = 0
                while (sci < 50) {
                    val set = new java.util.HashSet[Int]()
                    set.add(1)
                    set.add(2)
                    set.add(3)
                    set.add(4)

                    this.result.put(sci, set)
                    engine ! WinnerBackTestAlphaStart(engine, sci, num)
                    sci += 1
                }
            } match {
                case Success(_) =>
                case Failure(e) =>
                    e.printStackTrace(System.out)
                    println(s"*** Error: [${e.getMessage}]")
                    println("System Stop. Please try again")
            }
        case WinnerWorkDone(id, num, remove) =>
            Try {
                println(s"Id[$id] [$num] WinnerWorkDone Done.")

                if (remove) {
                    val set = this.result.get(id).asInstanceOf[java.util.Set[Int]]
                    set.remove(num)
                    if (set.size() == 0) {
                        this.result.remove(id)
                    }
                    if (this.result.size() <= 0) {
                        this.locker.synchronized {
                            this.locker.notifyAll()
                        }
                    }
                }
            } match {
                case Success(_) =>
                case Failure(e) =>
                    e.printStackTrace(System.out)
                    println("System Stop. Please try again")
            }
        case WinnerAddCase(engine, id, num) =>
            println(s"Id[$id] [$num] WinnerAddCase Done.")
            engine ! WinnerBackTestAlphaStartAddCase(engine, id, num)
        case WriteWinnerReport(id, num) =>
            println(s"Id[$id] [$num] WriteWinnerReport Done")
            self ! WinnerWorkDone(id, num, false)
        case t =>
            throw new RuntimeException(s"Should not be here.Please debug! Receive Class[${t.getClass.toString}]")
    }
}