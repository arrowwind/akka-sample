package com.heitu.akkaactor.winner.alpha

import akka.actor.{Actor, ActorRef, Props}
import com.heitu.akkaactor.CitaEngine.{WinnerAddCase, WinnerWorkDone, WriteWinnerReport}
import com.heitu.akkaactor.winner.alpha.WinnerAlphaEngine.{WinnerBackTestAlphaStart, WinnerBackTestAlphaStartAddCase}

import java.io.IOException
import java.math.RoundingMode
import java.util
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.{Failure, Success, Try}

object WinnerAlphaEngine {
    def props(): Props = Props(new WinnerAlphaEngine())

    final case class WinnerBackTestAlphaStart(engine: ActorRef, id: Int, num: Int)

    final case class WinnerBackTestAlphaStartAddCase(engine: ActorRef, id: Int, num: Int)
}

class WinnerAlphaEngine() extends Actor {
    var engine: ActorRef = _

    private def backTestStart(id: Int, num: Int, isAddCase: Boolean): Unit = {
        Thread.sleep(1000)
        if (num > 1) {
            sender() ! WinnerAddCase(engine, id, num - 1)
            sender() ! WriteWinnerReport(id, num)
        }

        if (isAddCase) {
            println(s"Id[$id] [$num] WinnerBackTestAlphaStartAddCase Done.")
        } else {
            println(s"Id[$id] [$num] WinnerBackTestAlphaStart Done.")
        }

        sender() ! WinnerWorkDone(id, num, true)
    }

    override def receive: PartialFunction[Any, Unit] = {
        case WinnerBackTestAlphaStartAddCase(engine, id, num) =>
            this.engine = engine
            this.backTestStart(id, num, isAddCase = true)
        case WinnerBackTestAlphaStart(engine, id, num) =>
            this.engine = engine
            this.backTestStart(id, num, isAddCase = false)
        case t =>
            throw new RuntimeException(s"Should not be here.Please debug! Receive Class[${t.getClass.toString}]")
    }
}